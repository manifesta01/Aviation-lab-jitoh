package com.example.aviatorresearchlab

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.EditText
import android.widget.Toast

class MainActivity : Activity() {
    private val history = mutableListOf<Double>()
    private lateinit var summary: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
        }

        val heading = TextView(this).apply {
            text = "Aviator Research Lab"
            textSize = 25f
        }
        layout.addView(heading)

        val intro = TextView(this).apply {
            text = "Read-only research prototype\nEnter completed round multipliers to study historical results."
            textSize = 15f
            setPadding(0, 16, 0, 20)
        }
        layout.addView(intro)

        val entry = EditText(this).apply {
            hint = "Completed multiplier, e.g. 2.35"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        layout.addView(entry)

        val add = Button(this).apply {
            text = "Add completed round"
            setOnClickListener {
                val value = entry.text.toString().trim().removeSuffix("x").toDoubleOrNull()
                if (value == null || value < 1.0) {
                    Toast.makeText(this@MainActivity, "Enter a multiplier of 1.00 or higher", Toast.LENGTH_SHORT).show()
                } else {
                    history.add(value)
                    entry.text.clear()
                    updateSummary()
                }
            }
        }
        layout.addView(add)

        summary = TextView(this).apply {
            textSize = 16f
            setPadding(0, 24, 0, 16)
            text = "No rounds recorded yet."
        }
        layout.addView(summary)

        val caution = TextView(this).apply {
            text = "Important: past results do not reveal the next crash point. This app does not provide guaranteed predictions or place bets."
            textSize = 13f
        }
        layout.addView(caution)
        setContentView(layout)
    }

    private fun updateSummary() {
        val sorted = history.sorted()
        val mean = history.average()
        val low = history.count { it < 2.0 }
        val medium = history.count { it >= 2.0 && it < 10.0 }
        val high = history.count { it >= 10.0 }
        summary.text = "Rounds recorded: ${history.size}\n" +
            "Average: ${"%.2f".format(mean)}x\n" +
            "Low (1.00–1.99x): $low\n" +
            "Medium (2.00–9.99x): $medium\n" +
            "High (10x+): $high"
    }
}
