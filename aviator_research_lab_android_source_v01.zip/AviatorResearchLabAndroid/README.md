# Aviator Research Lab — Android starter

This is an early Android source-code starter, not a finished or tested APK.

## Build
- Open this folder in Android Studio on a computer.
- Use JDK 17 and Android Gradle Plugin 8.7.3.
- Allow Gradle to sync, then build the `app` debug APK.

## Current scope
- Simple local entry of completed multipliers.
- Descriptive counts and average.
- No connection to Betway, no screen reading, no OCR, no automatic monitoring, and no betting actions.

## Important limitation
Aviator outcomes are not reliably predictable from past multipliers. Any future statistical estimates must be treated as experimental and validated against a baseline using chronological out-of-sample testing. Never treat them as betting advice.
